#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=1:00:00
#PBS -d ./

module load vcftools
vcftools --vcf dbSNP.vcf --out testing_vcf --SNPdensity 10000
cat testing_density.R | R --slave

echo "Done"
