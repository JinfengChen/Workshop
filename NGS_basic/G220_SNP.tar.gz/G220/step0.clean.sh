rm ALL.gatk.*
rm -R aln*
rm read*.trim.* read*_*
rm ref.fa.* ref.dict
rm repeat.bed.idx
rm bam.list
rm testing_vcf.*
rm dbSNP.tab*
