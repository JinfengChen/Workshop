#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=10:00:00
#PBS -d ./

#cd $PBS_O_WORKDIR

module load samtools
module load bwa
bwa index ref.fa
bwa aln ref.fa read1.trim.fq > aln1.sai
bwa aln ref.fa read2.trim.fq > aln2.sai
bwa sampe ref.fa aln1.sai aln2.sai read1.trim.fq read2.trim.fq > aln.sam

samtools view -bS -o aln.raw.bam aln.sam
samtools sort aln.raw.bam aln.sort
java -jar /opt/picard/1.81/MarkDuplicates.jar ASSUME_SORTED=TRUE REMOVE_DUPLICATES=TRUE VALIDATION_STRINGENCY=LENIENT INPUT=aln.sort.bam OUTPUT=aln.bam METRICS_FILE=aln.dupli
java -jar /opt/picard/1.81/AddOrReplaceReadGroups.jar INPUT=aln.bam OUTPUT=aln.rg.bam SORT_ORDER=coordinate CREATE_INDEX=true RGID=Rice01 RGLB=RiceLib1 RGPL=Illumina RGPU=Genomic RGSM=Rice01 VALIDATION_STRINGENCY=SILENT
samtools flagstat aln.bam > aln.flagstat


echo "Done"

