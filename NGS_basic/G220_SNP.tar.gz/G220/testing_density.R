pdf("testing_vcf.snpden.pdf", width = 10, height = 4)
x <- read.table("testing_vcf.snpden", header=TRUE)
plot(x[,2]/1000000, x[,4], col='cadetblue', type='l', main="", xlab="Chromosomal Position (Mb)",  ylab="Count/10 kb", xlim=c(0, 45), ylim=c(0, 10), frame.plot=FALSE)
dev.off()
