#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=100:00:00
#PBS -d ./

module load vcftools
bgzip ALL.gatk.snp.raw.vcf
tabix -p vcf ALL.gatk.snp.raw.vcf.gz
bgzip ALL.gatk.snp.pass.vcf
tabix -p vcf ALL.gatk.snp.pass.vcf.gz
bgzip ALL.gatk.snp.final.vcf
tabix -p vcf ALL.gatk.snp.final.vcf.gz
vcf-compare ALL.gatk.snp.raw.vcf.gz ALL.gatk.snp.pass.vcf.gz ALL.gatk.snp.final.vcf.gz

echo "Done"
