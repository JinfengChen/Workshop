#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=100:00:00
#PBS -d ./


module load samtools
java -jar /opt/picard/1.81/CreateSequenceDictionary.jar R=ref.fa O=ref.dict
samtools faidx ref.fa

echo "Done"

