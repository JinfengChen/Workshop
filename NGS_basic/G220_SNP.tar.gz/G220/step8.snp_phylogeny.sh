#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=1:00:00
#PBS -d ./


module load vcftools
vcf-to-tab < dbSNP.vcf > dbSNP.tab
perl vcf_tab_to_fasta_alignmentv1.pl -i dbSNP.tab

echo "Done"
