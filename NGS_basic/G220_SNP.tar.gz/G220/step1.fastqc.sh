#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=100:00:00
#PBS -d ./

module load fastqc
fastqc -o ./ -f fastq read1.fastq read2.fastq

echo "Done"
