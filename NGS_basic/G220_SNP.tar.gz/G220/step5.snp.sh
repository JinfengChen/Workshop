#!/bin/sh
#PBS -l nodes=1:ppn=1
#PBS -l mem=5gb
#PBS -l walltime=1:00:00
#PBS -d ./

PICARD=/opt/picard/1.81
GATK=/opt/GATK/3.4.0/GenomeAnalysisTK.jar
JAVA=/opt/java/jdk1.7.0_17/bin/java
genome=../reference/ref.fa
dbSNP=./dbSNP.vcf
repeat=./repeat.bed
BAM=./bam.list
prefix=ALL
mem=1
cpu=1

ls aln.rg.bam > bam.list

###snp call
if [ ! -e $prefix.gatk.raw.vcf ]; then
$JAVA -Xmx1g -jar $GATK \
      -T HaplotypeCaller \
      -R $genome \
      -I $BAM \
      -o $prefix.gatk.raw.vcf \
      -nct $cpu \
      --genotyping_mode DISCOVERY \
      -stand_call_conf 30 \
      -stand_emit_conf 10 \
      
fi

###Extract SNP and indel
if [ ! -e $prefix.gatk.snp.raw.vcf ]; then
$JAVA -Xmx1g -jar $GATK \
      -T SelectVariants \
      -R $genome \
      -V $prefix.gatk.raw.vcf \
      -selectType SNP \
      -o $prefix.gatk.snp.raw.vcf

$JAVA -Xmx1g -jar $GATK \
      -T SelectVariants \
      -R $genome \
      -V $prefix.gatk.raw.vcf \
      -selectType INDEL \
      -o $prefix.gatk.indel.raw.vcf
fi


###hardfilter snp
if [ ! -e $prefix.gatk.snp.final.vcf ]; then
$JAVA -Xmx1g -jar $GATK \
      -T VariantFiltration \
      -R $genome \
      -V $prefix.gatk.snp.raw.vcf \
      --filterExpression "QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
      --filterName "my_snp_filter" \
      -o $prefix.gatk.snp.hardfilter.vcf

$JAVA -Xmx1g -jar $GATK -T SelectVariants -R $genome -V $prefix.gatk.snp.hardfilter.vcf -o $prefix.gatk.snp.pass.vcf --excludeFiltered

###mask repeat
$JAVA -Xmx1g -jar $GATK \
      -T VariantFiltration \
      -R $genome \
      --variant $prefix.gatk.snp.pass.vcf \
      -o $prefix.gatk.snp.pass.repeat.vcf \
      --mask $repeat \
      --maskName "REPEAT"

$JAVA -Xmx1g -jar $GATK -T SelectVariants -R $genome --variant $prefix.gatk.snp.pass.repeat.vcf -o $prefix.gatk.snp.final.vcf --excludeFiltered
fi

echo "Done!"
