#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=1:00:00
#PBS -d ./

module load samtools
samtools flagstat aln.rg.bam > aln.rg.bam.flagstats
/rhome/cjinfeng/BigData/software/qualimap/qualimap_v2.1.2/qualimap bamqc -bam aln.rg.bam --java-mem-size=2G -nt 1 -outformat PDF


echo "Done"

