#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=2gb
#PBS -l walltime=100:00:00
#PBS -d ./

java -classpath /rhome/cjinfeng/BigData/software/Trimmomatic-0.30/trimmomatic-0.30.jar org.usadellab.trimmomatic.TrimmomaticPE -phred33 read1.fastq read2.fastq read1.trim.fq read1.trim.unpaired.fq read2.trim.fq read2.trim.unpaired.fq SLIDINGWINDOW:4:15 ILLUMINACLIP:adapter.fa:2:40:15 MINLEN:40

echo "Done"
